/** Automatically generated file. DO NOT MODIFY */
package com.ldw.music;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}