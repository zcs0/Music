/**
 * Copyright (c) www.longdw.com
 */
package com.ldw.music.view;

public interface onViewChangeListener {
	public void OnViewChange(int view);
}
