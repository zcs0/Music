/**
 * Copyright (c) www.longdw.com
 */
package com.ldw.music.interfaces;

import android.view.View;

public interface IOnSlidingHandleViewClickListener {
	void onViewClick(View view) ;
}
