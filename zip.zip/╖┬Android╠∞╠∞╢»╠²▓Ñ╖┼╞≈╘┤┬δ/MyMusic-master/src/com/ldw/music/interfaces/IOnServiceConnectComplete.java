/**
 * Copyright (c) www.longdw.com
 */
package com.ldw.music.interfaces;

import com.ldw.music.aidl.IMediaService;

public interface IOnServiceConnectComplete {

	public void onServiceConnectComplete(IMediaService service);
}

